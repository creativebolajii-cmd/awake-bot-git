---
name: Orval zod body naming
description: Why generated zod request-body schemas don't match the OpenAPI component name you $ref'd
---

Orval's zod output (`lib/api-zod/src/generated/api.ts`) names request-body and response schemas after the operation, not the component: `<OperationIdPascal>Body` and `<OperationIdPascal>Response` (e.g. operation `scrape9jarocks` with body `$ref: '#/components/schemas/ScrapeInput'` still generates a zod const named `Scrape9jarocksBody`, not `ScrapeInput`).

This is separate from the TypeScript interfaces in `generated/types/`, which ARE named after the entity/component (e.g. `ScrapeInput` interface exists there).

**Why:** The `pnpm-workspace` skill's naming-collision rule (entity-shaped component names to avoid `TS2308`) governs the *component* name in the OpenAPI spec, but doesn't change how Orval names the zod schema it emits per-operation.

**How to apply:** When importing zod schemas for server-side validation from `@workspace/api-zod`, always grep the actual exported const names in `generated/api.ts` first (`grep "^export const" lib/api-zod/src/generated/api.ts`) rather than assuming the OpenAPI component name is importable as a zod schema. The entity name only exists as a TS type, not a zod validator.
