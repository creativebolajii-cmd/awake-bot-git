---
name: Python subprocess in Node api-server
description: Pattern for wrapping a legacy Python scraper/CLI inside the Express api-server instead of a separate artifact
---

When a project ports in an existing Python tool (e.g. a BeautifulSoup scraper) and the free-tier/artifact-count constraints don't allow a standalone Python service, embed it inside the existing `artifacts/api-server` (Express) via `child_process.spawn`, rather than rewriting the logic in TypeScript or creating a new artifact.

**Why:** Porting nontrivial scraping/parsing logic to TS risks subtly breaking behavior that was already working against real-world HTML, for no functional benefit. A single Node process spawning Python per request is simpler to deploy than running two services and keeps within a one-new-artifact budget.

**How to apply:**
- Keep the Python source under `artifacts/api-server/src/<subdir>/`, with a small stdin(JSON) → stdout(JSON) CLI wrapper script as the single entry point — this avoids needing an HTTP server on the Python side.
- Resolve the Python binary via an overridable env var (e.g. `PYTHON_BIN`) with a sensible default for the dev sandbox (Replit's uv-managed venv lives at `.pythonlibs/bin/python3`, not a system `python3`), so the same code works in Replit dev and in a Docker/Render deployment with a different venv path.
- esbuild only bundles JS/TS — non-JS asset files invoked via `spawn` (like `.py` scripts) are not touched by the build step; they're referenced from source, so a full-repo deploy target (like Replit's own deploy) works without extra copying, but an isolated Docker build must explicitly copy those source directories and install the Python deps (`requirements.txt` mirroring `pyproject.toml`) into the image.
