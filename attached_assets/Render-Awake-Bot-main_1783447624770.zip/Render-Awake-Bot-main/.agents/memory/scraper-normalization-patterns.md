---
name: Scraper title/status normalization patterns
description: Non-obvious site quirks and normalization rules discovered while fixing AwakeMovies Scraper bugs (Elementor trailers, NaijaPrey status, title cleaning)
---

## Elementor video widgets don't use plain iframe `src`

Some WordPress sites (e.g. Nkiri/Dramakey) embed trailers via Elementor's video widget, which stores the YouTube URL inside a `data-settings` JSON attribute (key `youtube_url`) rather than a visible `<iframe src="...">`. Trailer scraping must fall back to parsing `data-settings` JSON when no iframe/video src is found, or trailers silently come back empty on Elementor-built pages.

**Why:** discovered via a real failing page where the trailer was fully present in the HTML but invisible to naive iframe/video-tag scraping.

**How to apply:** any new site scraper that fails to find a trailer should check for Elementor widget markup before concluding the trailer is missing.

## NaijaPrey series-completion status heuristic

NaijaPrey doesn't always mark completion with an explicit "(complete)" text label. The reliable rule (confirmed by user): compare the declared "Episodes: N" count against the count of *actually working* episode links found on the page (some episode links are HTML-commented-out / dead). If declared count == working count → status "Completed"; otherwise → "Added". Keep the literal "(complete)" text detection as an additional/first-priority signal, but don't rely on it alone.

**Why:** sites sometimes advertise a season as complete in text while episode links are stubbed out or not yet live, and vice versa — text alone caused wrong statuses.

## Title-cleaning gotchas across scrapers (normalizer + nkiri_dramakey)

- Genre/type parenthetical tags can be **two words**, not one (e.g. `(Chinese Drama)`, `(Hollywood Movie)`) — a regex alternation of single tag words won't match these; it needs an optional nationality/region word followed by the type word (Drama/Movie/TV Series).
- Site descriptions are sometimes appended as a full trailing sentence after the title with no separator other than a period, e.g. `Deep In (Chinese Drama). DramaKey is the home of all Asian...` — strip everything from `. <SiteName>` onward.
- Series season/status info appears in multiple inconsistent shapes on real pages: `Season N`, abbreviated `S01`, and status baked into an episode-progress parenthetical like `(Episode 4 Added)` — all three needed separate strip rules; matching only `Season \d+` misses the other two silently (title looked "fine" but retained cruft).
- Movie sequels use a trailing bare number pattern (`Title N (Year)` → `Title part N`); year is intentionally dropped since the sequel number already disambiguates.

**Why:** each of these came from a real scraped title that looked plausible after a naive fix but still contained leftover junk — worth re-testing against literal raw HTML title strings, not just designed test cases, when touching this normalization logic again.
