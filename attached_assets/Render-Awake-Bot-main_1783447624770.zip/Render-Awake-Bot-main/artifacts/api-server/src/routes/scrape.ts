import { Router, type IRouter } from "express";
import {
  Scrape9jarocksBody,
  Scrape9jarocksResponse,
  ScrapeNaijapreyBody,
  ScrapeNaijapreyResponse,
  ScrapeNkiriDramakeyBody,
  ScrapeNkiriDramakeyResponse,
  ListScrapeSourcesResponse,
} from "@workspace/api-zod";
import { runScrape } from "../lib/pythonRuntime";

const router: IRouter = Router();

router.get("/scrape/sources", (_req, res): void => {
  const sources = ListScrapeSourcesResponse.parse([
    { id: "9jarocks", label: "9jarocks", needsSite: false },
    { id: "naijaprey", label: "NaijaPrey", needsSite: false },
    { id: "nkiri-dramakey", label: "Nkiri / Dramakey", needsSite: true },
  ]);
  res.json(sources);
});

router.post("/scrape/9jarocks", async (req, res): Promise<void> => {
  const parsed = Scrape9jarocksBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const result = await runScrape({ source: "9jarocks", ...parsed.data });
    res.json(Scrape9jarocksResponse.parse(result));
  } catch (err) {
    req.log.error({ err }, "9jarocks scrape failed");
    res.status(500).json({ error: "DOWNLOAD RESOLUTION FAILED" });
  }
});

router.post("/scrape/naijaprey", async (req, res): Promise<void> => {
  const parsed = ScrapeNaijapreyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const result = await runScrape({ source: "naijaprey", ...parsed.data });
    res.json(ScrapeNaijapreyResponse.parse(result));
  } catch (err) {
    req.log.error({ err }, "naijaprey scrape failed");
    res.status(500).json({ error: "DOWNLOAD RESOLUTION FAILED" });
  }
});

router.post("/scrape/nkiri-dramakey", async (req, res): Promise<void> => {
  const parsed = ScrapeNkiriDramakeyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const result = await runScrape({ source: "nkiri-dramakey", ...parsed.data });
    res.json(ScrapeNkiriDramakeyResponse.parse(result));
  } catch (err) {
    req.log.error({ err }, "nkiri-dramakey scrape failed");
    res.status(500).json({ error: "DOWNLOAD RESOLUTION FAILED" });
  }
});

export default router;
