import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Loader2, TerminalSquare } from "lucide-react";

import {
  useListScrapeSources,
  useScrape9jarocks,
  useScrapeNaijaprey,
  useScrapeNkiriDramakey,
  ScrapeResult
} from "@workspace/api-client-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  url: z.string().url({ message: "Please enter a valid URL." }),
  sourceId: z.string().min(1, { message: "Please select a source." }),
  mode: z.enum(["movie", "series"]),
  site: z.enum(["nkiri", "dramakey"]).optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface ScraperFormProps {
  onResult: (result: ScrapeResult | null) => void;
  onLoading: (isLoading: boolean) => void;
}

export function ScraperForm({ onResult, onLoading }: ScraperFormProps) {
  const { toast } = useToast();
  const { data: sources, isLoading: sourcesLoading } = useListScrapeSources();
  
  const scrape9jarocks = useScrape9jarocks();
  const scrapeNaijaprey = useScrapeNaijaprey();
  const scrapeNkiri = useScrapeNkiriDramakey();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      url: "",
      sourceId: "",
      mode: "movie",
      site: "nkiri",
    },
  });

  const selectedSourceId = form.watch("sourceId");
  const selectedSource = sources?.find((s) => s.id === selectedSourceId);
  const isPending = scrape9jarocks.isPending || scrapeNaijaprey.isPending || scrapeNkiri.isPending;

  const onSubmit = async (values: FormValues) => {
    onLoading(true);
    onResult(null);

    const payload = {
      url: values.url,
      mode: values.mode as "movie" | "series",
    };

    const handleSuccess = (data: ScrapeResult) => {
      onResult(data);
      onLoading(false);
      if (data.error) {
        toast({
          title: "Scrape Failed",
          description: data.error,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Scrape Successful",
          description: "Data extracted successfully.",
        });
      }
    };

    const handleError = (error: any) => {
      onLoading(false);
      const message = error?.data?.error || error.message || "An unknown error occurred.";
      onResult({ error: message });
      toast({
        title: "Error",
        description: message,
        variant: "destructive",
      });
    };

    if (values.sourceId === "9jarocks") {
      scrape9jarocks.mutate({ data: payload }, { onSuccess: handleSuccess, onError: handleError });
    } else if (values.sourceId === "naijaprey") {
      scrapeNaijaprey.mutate({ data: payload }, { onSuccess: handleSuccess, onError: handleError });
    } else if (values.sourceId === "nkiri-dramakey") {
      scrapeNkiri.mutate(
        { data: { ...payload, site: values.site as "nkiri" | "dramakey" } },
        { onSuccess: handleSuccess, onError: handleError }
      );
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-sm">
      <div className="flex items-center gap-2 mb-6 text-primary">
        <TerminalSquare className="w-5 h-5" />
        <h2 className="font-mono font-bold uppercase tracking-wider">Execute_Scrape</h2>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="sourceId"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-muted-foreground text-xs uppercase">Source Target</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}>
                  <FormControl>
                    <SelectTrigger className="font-mono" data-testid="select-source">
                      <SelectValue placeholder={sourcesLoading ? "LOADING_SOURCES..." : "SELECT_TARGET"} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {sources?.map((source) => (
                      <SelectItem key={source.id} value={source.id} data-testid={`source-${source.id}`}>
                        {source.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {selectedSource?.needsSite && (
            <FormField
              control={form.control}
              name="site"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-muted-foreground text-xs uppercase">Sub_Site</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex gap-4"
                    >
                      <FormItem className="flex items-center space-x-2 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="nkiri" />
                        </FormControl>
                        <FormLabel className="font-normal font-mono cursor-pointer">Nkiri</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-2 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="dramakey" />
                        </FormControl>
                        <FormLabel className="font-normal font-mono cursor-pointer">DramaKey</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <FormField
            control={form.control}
            name="url"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-muted-foreground text-xs uppercase">Target_URL</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="https://..." 
                    {...field} 
                    className="font-mono bg-background/50 focus-visible:ring-primary" 
                    data-testid="input-url"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="mode"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-muted-foreground text-xs uppercase">Content_Type</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="grid grid-cols-2 gap-4"
                  >
                    <FormItem>
                      <FormControl>
                        <div className="relative">
                          <RadioGroupItem value="movie" className="peer sr-only" id="mode-movie" />
                          <Label
                            htmlFor="mode-movie"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary cursor-pointer font-mono uppercase tracking-widest text-sm"
                          >
                            Movie
                          </Label>
                        </div>
                      </FormControl>
                    </FormItem>
                    <FormItem>
                      <FormControl>
                        <div className="relative">
                          <RadioGroupItem value="series" className="peer sr-only" id="mode-series" />
                          <Label
                            htmlFor="mode-series"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary cursor-pointer font-mono uppercase tracking-widest text-sm"
                          >
                            Series
                          </Label>
                        </div>
                      </FormControl>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button 
            type="submit" 
            disabled={isPending} 
            className="w-full font-mono uppercase tracking-widest font-bold h-12 mt-4 hover:bg-primary/90 transition-colors"
            data-testid="button-scrape"
          >
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Processing...
              </>
            ) : (
              "Initialize_Scrape"
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
}
