import { useState } from "react";
import { ScrapeResult } from "@workspace/api-client-react";
import { AlertCircle, Copy, Download, Image as ImageIcon, Link as LinkIcon, Film, HardDrive, Clock, Globe2, Type, Braces } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CopyButton } from "@/components/ui/copy-button";
import { Button } from "@/components/ui/button";

interface ScraperResultProps {
  result: ScrapeResult;
}

function ResultRow({ label, value, icon: Icon }: { label: string; value?: string; icon?: any }) {
  if (!value) return null;
  return (
    <div className="flex items-start py-3 border-b border-border/50 last:border-0 group">
      {Icon && <Icon className="w-4 h-4 mr-3 mt-0.5 text-muted-foreground shrink-0" />}
      <div className="flex-1 min-w-0">
        <p className="text-xs font-mono text-muted-foreground uppercase mb-1">{label}</p>
        <p className="text-sm font-mono text-foreground break-words whitespace-pre-wrap">{value}</p>
      </div>
      <CopyButton value={value} className="opacity-0 group-hover:opacity-100 transition-opacity" />
    </div>
  );
}

export function ScraperResult({ result }: ScraperResultProps) {
  const [showJson, setShowJson] = useState(false);
  const jsonString = JSON.stringify(result, null, 2);

  const handleCopyJSON = async () => {
    await navigator.clipboard.writeText(jsonString);
  };

  if (result.error) {
    return (
      <div className="p-6 h-full flex items-center justify-center">
        <Alert variant="destructive" className="max-w-md bg-destructive/10 border-destructive/20 text-destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle className="font-mono uppercase tracking-wider font-bold">Scrape Failure</AlertTitle>
          <AlertDescription className="font-mono text-sm mt-2">
            {result.error}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-card rounded-lg border border-border shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 sm:p-4 border-b border-border bg-muted/20">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <Badge variant="outline" className="font-mono text-primary border-primary/30 uppercase shrink-0">
            {result._awpt_type || "UNKNOWN"}
          </Badge>
          <h3 className="font-bold text-base sm:text-lg truncate min-w-0" title={result._awpt_title}>
            {result._awpt_title || "No Title"}
          </h3>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button
            variant={showJson ? "default" : "outline"}
            size="sm"
            className="font-mono text-xs flex-1 sm:flex-none"
            onClick={() => setShowJson((v) => !v)}
            data-testid="button-toggle-json"
          >
            <Braces className="w-4 h-4 mr-2" />
            {showJson ? "Hide JSON" : "View JSON"}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="font-mono text-xs flex-1 sm:flex-none"
            onClick={handleCopyJSON}
            data-testid="button-copy-json"
          >
            <Copy className="w-4 h-4 mr-2" />
            Copy JSON
          </Button>
        </div>
      </div>

      {showJson && (
        <div className="border-b border-border bg-background/80 flex flex-col min-h-0" style={{ flexBasis: "45%" }}>
          <div className="flex items-center justify-between px-3 sm:px-4 py-2 border-b border-border/50 shrink-0">
            <span className="text-xs font-mono uppercase text-muted-foreground tracking-wider">Raw JSON</span>
            <CopyButton value={jsonString} size="sm" label="Copy" />
          </div>
          <ScrollArea className="flex-1 min-h-0">
            <pre className="p-3 sm:p-4 text-[11px] sm:text-xs font-mono text-foreground whitespace-pre-wrap break-words leading-relaxed">
              {jsonString}
            </pre>
          </ScrollArea>
        </div>
      )}

      <ScrollArea className="flex-1 p-3 sm:p-6 min-h-0">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 sm:gap-8">
          
          {/* Main Info Column */}
          <div className="xl:col-span-2 space-y-8">
            {/* Core Metadata */}
            <div className="bg-background/50 rounded-md border border-border/50 p-4">
              <ResultRow label="Title" value={result._awpt_title} icon={Type} />
              <ResultRow label="Synopsis" value={result._awpt_synopsis} />
              <ResultRow label="Genre" value={result._awpt_genre} icon={Film} />
              <ResultRow label="Stars/Cast" value={result._awpt_stars} />
              <ResultRow label="Trailer URL" value={result._awpt_trailer_url} icon={LinkIcon} />
            </div>

            {/* Downloads Section */}
            {result._awpt_download_link && result._awpt_download_link.length > 0 && (
              <div>
                <h4 className="font-mono text-sm font-bold text-muted-foreground uppercase mb-4 flex items-center">
                  <Download className="w-4 h-4 mr-2" /> Download Links
                </h4>
                <div className="grid gap-2">
                  {result._awpt_download_link.map((dl, idx) => (
                    <div key={idx} className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 bg-background/50 p-3 rounded border border-border/50 group hover:border-primary/50 transition-colors">
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <Badge variant="secondary" className="font-mono shrink-0">{dl.quality || "Any"}</Badge>
                        <span className="text-sm font-mono truncate text-muted-foreground">{dl.link}</span>
                      </div>
                      <CopyButton value={dl.link || ""} size="sm" className="shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Episodes Section */}
            {result._awpt_episodes && result._awpt_episodes.length > 0 && (
              <div>
                <h4 className="font-mono text-sm font-bold text-muted-foreground uppercase mb-4 flex items-center">
                  <Film className="w-4 h-4 mr-2" /> Episodes
                </h4>
                <div className="grid gap-2">
                  {result._awpt_episodes.map((ep, idx) => (
                    <div key={idx} className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 bg-background/50 p-3 rounded border border-border/50 group hover:border-primary/50 transition-colors">
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <Badge variant="outline" className="font-mono border-primary/30 text-primary shrink-0">
                          EP {ep.episode}
                        </Badge>
                        <span className="text-sm font-mono truncate max-w-[140px] sm:max-w-[200px]">{ep.title}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <CopyButton value={ep.url || ""} size="sm" label="URL" />
                        <CopyButton value={ep.title || ""} size="sm" label="Title" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar Column */}
          <div className="space-y-6">
            {/* Poster */}
            {result._awpt_poster ? (
              <div className="rounded-lg border border-border/50 overflow-hidden bg-background/50 relative group">
                <img 
                  src={result._awpt_poster} 
                  alt="Poster" 
                  className="w-full h-auto object-cover aspect-[2/3]"
                />
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <CopyButton value={result._awpt_poster} variant="secondary" className="bg-background/80 backdrop-blur" />
                </div>
              </div>
            ) : (
              <div className="aspect-[2/3] rounded-lg border border-dashed border-border/50 flex flex-col items-center justify-center text-muted-foreground bg-background/20">
                <ImageIcon className="w-8 h-8 mb-2 opacity-50" />
                <span className="font-mono text-xs uppercase">No Poster</span>
              </div>
            )}

            {/* Technical Specs */}
            <div className="bg-background/50 rounded-md border border-border/50 p-4">
              <ResultRow label="Duration" value={result._awpt_duration} icon={Clock} />
              <ResultRow label="File Size" value={result._awpt_file_size} icon={HardDrive} />
              <ResultRow label="Language" value={result._awpt_language} icon={Globe2} />
              <ResultRow label="Subtitles" value={result._awpt_subtitles} />
              <ResultRow label="Country" value={result._awpt_country} />
              <ResultRow label="Release Date" value={result._awpt_release_date} />
              
              {result._awpt_type === "series" && (
                <>
                  <ResultRow label="Season" value={result._awpt_season} />
                  <ResultRow label="Status" value={result._awpt_status} />
                  <ResultRow label="Total Episodes" value={result._awpt_total_episodes} />
                </>
              )}
              
              <ResultRow label="Source" value={result._awpt_source} />
            </div>
          </div>
          
        </div>
      </ScrollArea>
    </div>
  );
}
