import { useState } from "react";
import { ScraperForm } from "@/components/scraper-form";
import { ScraperResult } from "@/components/scraper-result";
import { ScrapeResult } from "@workspace/api-client-react";
import { Activity, Database } from "lucide-react";

export default function Home() {
  const [result, setResult] = useState<ScrapeResult | null>(null);
  const [isScraping, setIsScraping] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col selection:bg-primary selection:text-primary-foreground font-sans">
      <header className="border-b border-border bg-card/80 backdrop-blur px-4 sm:px-6 py-3 sm:py-4 flex flex-wrap items-center justify-between gap-2 sticky top-0 z-10">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <div className="w-8 h-8 shrink-0 rounded bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Activity className="w-5 h-5 text-primary" />
          </div>
          <div className="min-w-0">
            <h1 className="text-base sm:text-lg font-bold font-mono tracking-tight text-foreground leading-tight truncate">AWAKE_MOVIES</h1>
            <p className="text-[10px] sm:text-xs font-mono text-primary uppercase tracking-widest leading-none truncate">Metadata_Scraper_v1.0</p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="flex h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
          <span className="font-mono text-[10px] sm:text-xs text-muted-foreground uppercase whitespace-nowrap">System Online</span>
        </div>
      </header>

      <main className="flex-1 flex flex-col lg:flex-row gap-4 sm:gap-6 p-3 sm:p-6 max-w-[1800px] mx-auto w-full">
        {/* Left Column: Form */}
        <aside className="w-full lg:w-[420px] shrink-0 flex flex-col">
          <ScraperForm onResult={setResult} onLoading={setIsScraping} />
          
          <div className="mt-4 sm:mt-6 p-4 rounded border border-border/50 bg-card/30 text-xs font-mono text-muted-foreground flex flex-col gap-2">
            <p className="uppercase text-foreground font-bold mb-1 border-b border-border/50 pb-2">Instructions</p>
            <p>1. Select target source.</p>
            <p>2. Paste URL from source site.</p>
            <p>3. Select movie/series mode.</p>
            <p>4. Execute scrape.</p>
            <p>5. Copy fields for WordPress ingestion.</p>
          </div>
        </aside>

        {/* Right Column: Results */}
        <section className="flex-1 flex flex-col min-h-[500px] sm:min-h-[600px] lg:min-h-0 relative">
          {isScraping ? (
            <div className="absolute inset-0 z-10 bg-background/50 backdrop-blur-sm border border-border rounded-lg flex flex-col items-center justify-center animate-in fade-in duration-300 px-4 text-center">
              <div className="relative">
                <div className="w-14 h-14 sm:w-16 sm:h-16 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Database className="w-6 h-6 text-primary animate-pulse" />
                </div>
              </div>
              <p className="mt-6 font-mono text-primary uppercase tracking-widest font-bold text-sm sm:text-base">Extracting Data...</p>
              <p className="text-xs font-mono text-muted-foreground mt-2">Connecting to source host (times out after 35s)</p>
            </div>
          ) : result ? (
            <div className="h-full animate-in slide-in-from-bottom-4 duration-500">
              <ScraperResult result={result} />
            </div>
          ) : (
            <div className="flex-1 border border-dashed border-border/60 rounded-lg flex flex-col items-center justify-center bg-card/30 text-muted-foreground p-4 text-center">
              <Database className="w-12 h-12 mb-4 opacity-20" />
              <p className="font-mono text-sm uppercase tracking-widest">Awaiting Input</p>
              <p className="text-xs mt-2 opacity-60">System standing by for target URL.</p>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
