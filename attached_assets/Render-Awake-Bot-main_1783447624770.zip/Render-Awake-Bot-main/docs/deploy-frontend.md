# Hosting the Frontend on Vercel or Netlify

This deploys **only the frontend** (`artifacts/awakemovies-scraper`) as a
static site, pointed at your Render-hosted API from `docs/deploy-render.md`.
This is fully independent from Replit — Replit keeps running unchanged.

You need your Render API URL from Step 4 of `docs/deploy-render.md` first,
e.g. `https://awakemovies-api-server.onrender.com`.

The frontend is already wired to read this from an env var
(`VITE_API_BASE_URL`) — when it's unset, the app falls back to same-origin
requests (i.e. no change to how it behaves on Replit).

## Step 1 — Push this repo to GitHub

Same repo as the Render deploy — both Vercel/Netlify and Render can build
from the same GitHub repository, each picking their own subfolder.

```bash
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

## Option A — Vercel

1. Go to https://vercel.com/new and import your GitHub repo.
2. When asked for **Root Directory**, set it to:
   ```
   artifacts/awakemovies-scraper
   ```
3. Framework preset: **Vite** (Vercel should auto-detect it).
4. Build command: `pnpm install --filter=@workspace/awakemovies-scraper... && pnpm --filter @workspace/awakemovies-scraper run build`
   (This ensures pnpm workspace deps like `@workspace/api-client-react` are
   installed even though you're building from a subfolder.)
5. Output directory: `dist`
6. **Environment Variables** → add:
   | Key | Value |
   |---|---|
   | `VITE_API_BASE_URL` | `https://awakemovies-api-server.onrender.com` |
7. Click **Deploy**.

## Option B — Netlify

1. Go to https://app.netlify.com/start and connect your GitHub repo.
2. **Base directory**: `artifacts/awakemovies-scraper`
3. **Build command**:
   ```
   pnpm install --filter=@workspace/awakemovies-scraper... && pnpm --filter @workspace/awakemovies-scraper run build
   ```
4. **Publish directory**: `artifacts/awakemovies-scraper/dist`
5. Under **Site settings → Environment variables**, add:
   | Key | Value |
   |---|---|
   | `VITE_API_BASE_URL` | `https://awakemovies-api-server.onrender.com` |
6. Deploy.

## Step 2 — Allow this domain in the API's CORS

Once you have your live frontend URL (e.g. `https://your-app.vercel.app`),
go back to your Render service's environment variables and set:

```
ALLOWED_ORIGIN=https://your-app.vercel.app
```

Render will redeploy automatically after saving env var changes.

## Step 3 — Verify

Open your Vercel/Netlify URL, pick a source, paste a URL, and scrape. Network
requests should go to your Render API domain (check the browser's Network
tab) and come back with data.

## Redeploying after future code changes

Both Vercel and Netlify auto-deploy on every push to the connected branch,
same as Render. Push to `main` and it rebuilds automatically.
