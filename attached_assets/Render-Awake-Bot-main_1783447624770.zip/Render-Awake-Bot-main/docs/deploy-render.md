# Deploying the API Server to Render

This deploys **only the backend** (`artifacts/api-server`, including the Python
scraping engine) as a standalone Docker web service on Render. It runs
completely independently from the Replit environment — nothing here touches
your Replit deployment, and Replit will keep working exactly as it does today.

Files already prepared in this repo for you:

- `render.yaml` — Render "Blueprint" service definition
- `artifacts/api-server/Dockerfile` — multi-stage build (Node + Python venv)

## Step 1 — Push this repo to GitHub

Render deploys from a Git repository, not directly from Replit.

1. Create a new (private is fine) GitHub repository.
2. In the Replit Shell, connect and push:
   ```bash
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
   (If `origin` already exists, use `git push -u origin main` directly, or
   `git remote set-url origin <url>` first.)

## Step 2 — Create the Render Blueprint

1. Go to https://dashboard.render.com → **New** → **Blueprint**.
2. Connect your GitHub account and select the repo you just pushed.
3. Render will detect `render.yaml` at the repo root automatically and show
   you the `awakemovies-api-server` service it defines. Click **Apply**.
4. Render will build the Docker image (this installs Node deps, sets up a
   Python venv, installs `requirements.txt`, and builds the server). The
   first build takes a few minutes.

If you'd rather set it up manually instead of via Blueprint:

1. **New** → **Web Service** → connect the repo.
2. Runtime: **Docker**.
3. Dockerfile path: `artifacts/api-server/Dockerfile`
4. Docker build context: `.` (repo root — required, since the Dockerfile
   copies from `lib/` and `pnpm-workspace.yaml` at the root)
5. Plan: **Free** (or paid, your choice)
6. Health check path: `/api/healthz`

## Step 3 — Environment variables

The Dockerfile already sets `PYTHON_BIN`, `NODE_ENV`, and `PORT` for you — you
don't need to set those manually. Optionally set:

| Variable         | Purpose                                                                 | Default if unset |
|------------------|--------------------------------------------------------------------------|-------------------|
| `ALLOWED_ORIGIN` | Restrict CORS to your frontend's exact domain (e.g. `https://your-app.vercel.app`) | `*` (any origin) |

Set this in Render under your service → **Environment**.

## Step 4 — Get your live API URL

Once deployed, Render gives you a URL like:

```
https://awakemovies-api-server.onrender.com
```

Test it:

```bash
curl https://awakemovies-api-server.onrender.com/api/healthz
# -> {"status":"ok"}

curl https://awakemovies-api-server.onrender.com/api/scrape/sources
```

Keep this URL — you'll enter it as `VITE_API_BASE_URL` when hosting the
frontend (see `docs/deploy-frontend.md`).

## Step 5 — Prevent the free-tier server from sleeping

Render's free plan spins the service down after ~15 minutes of no traffic,
and the next request takes 30–60s to "wake" it. To keep it always warm,
set up an external scheduled ping (every 5 minutes) against the health
endpoint using **any** cron/uptime service you already use (cron-job.org,
UptimeRobot, GitHub Actions scheduled workflow, etc.):

**Endpoint to ping:**
```
https://awakemovies-api-server.onrender.com/api/healthz
```

Configure your ping service to hit that URL via `GET` every 5 minutes. A
`200 OK` with `{"status":"ok"}` means it's awake; that's all the check needs
to do — no auth, no payload.

> This only prevents idle spin-down; it does not increase Render's monthly
> free-tier usage-hour cap. If you exceed that cap, Render will still stop
> the service until the next billing cycle.

## Redeploying after future code changes

Render auto-deploys on every push to the branch you connected (default
`main`). Just `git push` and Render rebuilds automatically. No manual
redeploy step needed unless you disable auto-deploy in the service settings.
