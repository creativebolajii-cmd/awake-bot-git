# Keeping Both Deployments Awake

You'll have two **standalone** production backends running independently:

1. **Replit deployment** (this project, published via Replit)
2. **Render deployment** (from `docs/deploy-render.md`)

Neither knows about the other — they're separate copies of the same backend
code, each with their own data/URL. Both can go idle/sleep on their own
schedule depending on your plan, so ping each one separately, every 5
minutes, with your own external cron/uptime service.

## Endpoint 1 — Replit deployment

```
https://<your-replit-deployment-domain>/api/healthz
```

Replace `<your-replit-deployment-domain>` with your published Replit app's
domain (shown after you deploy — looks like `your-app-name.replit.app`, or
your custom domain if you set one up). This is separate from the
`*.replit.dev` domain you use during development in the workspace.

## Endpoint 2 — Render deployment

```
https://awakemovies-api-server.onrender.com/api/healthz
```

(Use whatever URL Render actually assigned your service — check your Render
dashboard if you renamed it.)

## What to configure

In your ping service (cron-job.org, UptimeRobot, GitHub Actions cron, or
whatever you already use), create **two separate jobs**, each:

- Method: `GET`
- Interval: every 5 minutes
- URL: one of the two endpoints above
- Expected response: `200 OK`, body `{"status":"ok"}`

No headers, auth, or request body are required — `/api/healthz` is a public,
unauthenticated endpoint on both deployments.

## Notes

- This prevents *idle* spin-down only. It does not bypass platform-level
  caps (e.g. Render's free-tier monthly usage-hour limit, or Replit's own
  compute limits on your plan).
- The frontend (Vercel/Netlify, static hosting) never sleeps — there's
  nothing to keep alive there. Only the two backend services above need
  pinging.
