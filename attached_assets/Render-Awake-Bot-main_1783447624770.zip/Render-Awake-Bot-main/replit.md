# AwakeMovies Scraper

An internal tool that scrapes movie/series metadata (title, synopsis, poster, cast, download links, episodes, etc.) from 9jarocks, NaijaPrey, and Nkiri/Dramakey so a small publishing team can quickly copy structured data into WordPress.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/awakemovies-scraper run dev` — run the scraper console frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required env: none for the scraper itself (no DB used yet)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5, with a Python 3.11 scraping engine (BeautifulSoup + lxml) invoked via `child_process`
- Frontend: React + Vite (`artifacts/awakemovies-scraper`)
- Validation: Zod (`zod/v4`)
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild

## Where things live

- `artifacts/api-server/src/scrapers/` — Python scraper modules (`ninejarocks.py`, `naijaprey.py`, `nkiri_dramakey.py`, `normalizer.py`) ported from the original uploaded project, plus `run_scrape.py` (stdin/stdout JSON wrapper)
- `artifacts/api-server/src/lib/pythonRuntime.ts` — spawns the Python wrapper and returns parsed JSON to Express routes
- `artifacts/api-server/src/routes/scrape.ts` — `/api/scrape/9jarocks`, `/api/scrape/naijaprey`, `/api/scrape/nkiri-dramakey`, `/api/scrape/sources`
- `artifacts/awakemovies-scraper/` — the scraper console frontend
- `lib/api-spec/openapi.yaml` — source of truth for the scrape API contract
- `render.yaml` + `artifacts/api-server/Dockerfile` — prepped for the user to deploy the API server on Render themselves (installs Python + pip deps in the image)
- `docs/deploy-render.md` — step-by-step guide to deploy the API server standalone on Render
- `docs/deploy-frontend.md` — step-by-step guide to host the frontend standalone on Vercel or Netlify, pointed at the Render API
- `docs/keep-alive.md` — health-check ping endpoints for both the Replit and Render deployments (each is standalone and can idle independently)

## Architecture decisions

- The original project's Python scraper logic (BeautifulSoup-based, site-specific parsing) was kept as-is rather than ported to TypeScript — it's battle-tested against real site HTML and porting risked breaking scraping logic for no benefit.
- Python is invoked from the existing Express `api-server` via `child_process.spawn`, not a separate Python service — this respects the one-new-artifact constraint and keeps deployment simple (one Node process spawning Python per request).
- `PYTHON_BIN` env var overrides the default `.pythonlibs/bin/python3` path so the same code runs in Replit (uv-managed venv) and Render (Docker image with a venv at `/repo/.pyvenv`).
- A prior `delivery-gateway` (Telegram bot + WordPress publisher) subproject from the original upload was intentionally NOT built yet — deferred to a later phase since the user doesn't have a Telegram bot token yet.

## Product

- A single-page scraper console: pick a source, paste a URL, choose movie/series mode (and site for Nkiri/Dramakey), scrape, and copy the structured result (or full JSON) for pasting into WordPress.
- `GET /api/scrape/sources` lists supported sources for the picker.

## User preferences

- Deploy on Replit (agent-managed) AND separately prep the code for Render (user will do the Render setup themselves using their own account).
- Telegram bot + delivery-gateway integration is phase 2 — do not build until the user provides a bot token and asks for it.

## Gotchas

- The Python runtime lives at `.pythonlibs/bin/python3` in Replit's dev environment (uv-managed), not a system `python3` on PATH. Render/Docker deployments must set `PYTHON_BIN` to their own venv path (see Dockerfile).
- Scrape failures (dead links, changed site markup) return `{"error": "..."}` with HTTP 500 rather than crashing — always check for the `error` field in results.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
